<?php
//check multidimensions array
/**
 * 
 */
class BinaxArray
{
	//check whether multidimension or not
		function is_multi($array) {
		    return (count($array) != count($array, 1));
		}
	
}
  ?>