<?php
if (isset($_POST))
 {
$name = $_POST['name'];
$email   = $_POST['email'];
$data = array('name' => $name, 'email'=>$email);
echo  json_encode($data); 
}
  ?>