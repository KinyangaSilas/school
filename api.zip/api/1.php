<?php
$data =array(
  			"version"=>1,
  			"developer"=>"binax",
  			"type"=>"API",
  			"token" =>"abcf12fa"
			);
echo json_encode($data);
?>