<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class B_Animal extends CI_Model
{
}
?>