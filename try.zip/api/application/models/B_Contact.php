<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class B_Contact  extends CI_Model
{
	private $id,$password,$date_created,$date_updated,$first_name,$last_name,$ward_id,$token,$specialisation;
	public $phone,$email,$alt_phone;

}
?>