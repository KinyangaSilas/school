<?php
//require_once '../db.php';
//$db = new db();
$data =array();
/* json response array
$response = array("error" => FALSE);
 
    // receiving the post params
$phone = $_POST['phone'];
$password = $_POST['password'];
 
    // get the user 
$users = $db->getAll("SELECT * FROM `users` WHERE `phone`= '$phone' AND `password`= '$password' "); 
$data =array(
  			"success"=>true,
  			"user"=>(object)$users,
  			"vendor"=>"binax ltd"
		);*/
echo json_encode($data);

?>